# flappyBird
A simple js clone of flappy bird
It is Live [here](https://hkirat.github.io/flappyBird)
